package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController; 

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
	
	@GetMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		String data = "Hello Ethan Vu! Artemis Financial Check Sum!";

		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));

		return "<p>data: " + data + "</p>" + "<p>Name of Cipher Algorithm Used: SHA-256 : CheckSum Value: " + bytesToHex(hash) + "</p>";
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuilder hex = new StringBuilder(2 * bytes.length);
		for (byte b : bytes) {
			hex.append(String.format("%02x", b));
		}
		return hex.toString();
	}
}